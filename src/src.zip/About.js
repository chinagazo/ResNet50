import React, { Component } from 'react';
import './About.css';

class About extends Component{
    render(){
        return(
            <>
                <div class="WHAT-WE-DO">
                    what we do 
                </div>
                <div class="We-connect-to-people">
                We connect to people who want to fight a match to help people to get inspired <br />
workout more often. Through pose estimation technology, <br />
we track your bone <br />
structure and count your movements. <br /> 
                </div>
            </>
        );
    }

}

export default About;